// LeadSpringer Worker (homepage + /api/*)
// Requires a Cloudflare Secret named: OPENAI_API_KEY

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    // --- Small helpers
    const sendJSON = (obj, status = 200, extraHeaders = {}) =>
      new Response(JSON.stringify(obj), {
        status,
        headers: {
          "content-type": "application/json",
          "access-control-allow-origin": "*",
          ...extraHeaders,
        },
      });

    const sendHTML = (html, status = 200) =>
      new Response(html, {
        status,
        headers: {
          "content-type": "text/html; charset=utf-8",
          "x-content-type-options": "nosniff",
        },
      });

    // --- CORS preflight
    if (request.method === "OPTIONS") {
      return new Response(null, {
        headers: {
          "access-control-allow-origin": "*",
          "access-control-allow-methods": "GET,POST,OPTIONS",
          "access-control-allow-headers": "content-type,authorization",
          "access-control-max-age": "86400",
        },
      });
    }

    // --- Health
    if (url.pathname === "/api/diagnostics") {
      return sendJSON({
        ok: true,
        worker: "online",
        has_api_key: Boolean(env.OPENAI_API_KEY),
        now_utc: new Date().toISOString(),
      });
    }

    // --- AI Ask (POST { question })
    if (url.pathname === "/api/ask" && request.method === "POST") {
      try {
        if (!env.OPENAI_API_KEY) {
          return sendJSON({ error: "OPENAI_API_KEY is not set." }, 500);
        }
        const { question } = await request.json();
        if (!question || typeof question !== "string") {
          return sendJSON({ error: "Body must be { question: string }" }, 400);
        }

        const r = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${env.OPENAI_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "gpt-4.1-mini",
            messages: [{ role: "user", content: question }],
          }),
        });

        if (!r.ok) {
          const err = await r.text();
          return sendJSON({ error: "OpenAI error", detail: err }, r.status);
        }

        const data = await r.json();
        const answer = data?.choices?.[0]?.message?.content ?? "(no answer)";
        return sendJSON({ answer });
      } catch (e) {
        return sendJSON({ error: "Server error", detail: String(e) }, 500);
      }
    }

    // --- Homepage
    if (url.pathname === "/" || url.pathname === "/index.html") {
      return sendHTML(homeHTML);
    }

    return new Response("Not found", { status: 404 });
  },
};

const homeHTML = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>LeadSpringer – AI Tools</title>
  <style>
    :root{--bg:#0b0d10;--card:#12161c;--text:#eaf0ff;--muted:#9fb0c9;--accent:#66e1b6;}
    *{box-sizing:border-box} body{margin:0;background:var(--bg);color:var(--text);font:16px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
    .wrap{max-width:880px;margin:40px auto;padding:24px}
    .card{background:var(--card);border:1px solid #1e2430;border-radius:16px;padding:20px;box-shadow:0 8px 30px rgba(0,0,0,.25)}
    h1{margin:0 0 6px;font-size:28px} p{color:var(--muted);margin:0 0 18px}
    .row{display:flex;gap:12px;flex-wrap:wrap}
    textarea{flex:1;min-height:90px;width:100%;padding:12px;border-radius:12px;border:1px solid #263042;background:#0f1319;color:var(--text)}
    button{white-space:nowrap;background:var(--accent);color:#04251b;border:none;border-radius:12px;padding:12px 16px;font-weight:600;cursor:pointer}
    button:disabled{opacity:.6;cursor:not-allowed}
    .out{margin-top:14px;padding:14px;border-radius:12px;background:#0e1320;border:1px solid #263042;min-height:60px}
    .pill{display:inline-block;font:12px/1.2 system-ui;background:#0e1522;border:1px solid #263042;color:var(--muted);padding:6px 10px;border-radius:999px;margin-right:8px}
    .footer{opacity:.7;margin-top:18px;font-size:13px}
    a{color:var(--accent);text-decoration:none}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1>LeadSpringer</h1>
      <p>Hands‑off AI utilities running on Cloudflare Workers.</p>
      <div class="pill">/api/ask</div>
      <div class="pill">/api/diagnostics</div>

      <div class="row" style="margin-top:12px">
        <textarea id="q" placeholder="Ask anything…"></textarea>
        <button id="askBtn">Ask AI</button>
      </div>

      <div id="out" class="out">Your answer will appear here…</div>
      <div class="footer">
        <a href="/api/diagnostics" target="_blank" rel="noopener">Diagnostics</a>
      </div>
    </div>
  </div>

<script>
const $ = (s)=>document.querySelector(s);
const btn = $("#askBtn"), q = $("#q"), out = $("#out");

btn.addEventListener("click", async ()=>{
  const question = q.value.trim();
  if(!question){ out.textContent = "Please type a question."; return; }
  btn.disabled = true; out.textContent = "Thinking…";
  try{
    const r = await fetch("/api/ask", {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({ question })
    });
    const data = await r.json();
    if(data.error){ out.textContent = "Error: " + (data.detail || data.error); }
    else { out.textContent = data.answer; }
  }catch(e){
    out.textContent = "Request failed: " + e;
  }finally{ btn.disabled = false; }
});
</script>
</body>
</html>`;
