# LeadSpringer – Cloudflare Worker (auto-deploy)

This repo hosts the LeadSpringer Worker (homepage + `/api/ask` + `/api/diagnostics`) and auto‑deploys to Cloudflare via GitHub Actions.

## Setup

1. Create a new GitHub repo and push these files.
2. In **GitHub → Settings → Secrets and variables → Actions**, add:
   - `CLOUDFLARE_API_TOKEN` – token with **Workers Scripts:Edit**, **Workers KV:Edit (optional)**, **Account:Read**, **Zone:Read**
   - `CLOUDFLARE_ACCOUNT_ID` – from Cloudflare dashboard
   - `OPENAI_API_KEY` – your OpenAI API key
3. Push to `main`. The Action will:
   - set/update the Worker secret `OPENAI_API_KEY`
   - deploy the Worker
   - attach routes from `wrangler.toml` to `leadspringer.com/*` and `www.leadspringer.com/*`

Endpoints:
- `/` – minimal GUI
- `/api/ask` – POST `{ "question": "..." }`
- `/api/diagnostics` – health check
